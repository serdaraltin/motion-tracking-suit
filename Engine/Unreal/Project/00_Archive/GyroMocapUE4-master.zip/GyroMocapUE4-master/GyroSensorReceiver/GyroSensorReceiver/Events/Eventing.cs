﻿using GyroSensorReceiver.Events.Events;

namespace GyroSensorReceiver.Events
{
    public static class Eventing
    {
        public static EventReceiveUdpServer EventReceiveUdpServer;
    }
}