﻿namespace GyroSensorReceiver.Models
{
    public class BaseModel
    {
        public string type;
    }
}