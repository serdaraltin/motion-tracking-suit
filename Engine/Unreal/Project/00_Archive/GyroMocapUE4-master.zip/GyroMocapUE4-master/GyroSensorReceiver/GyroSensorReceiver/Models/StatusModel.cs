﻿using GyroSensorReceiver.Models;

class StatusModel : BaseModel
{
    public int wifi_status;
    public string local_ip;
}