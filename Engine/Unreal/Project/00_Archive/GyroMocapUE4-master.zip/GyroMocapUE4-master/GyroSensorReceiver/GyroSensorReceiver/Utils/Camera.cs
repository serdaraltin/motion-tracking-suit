﻿namespace GyroSensorReceiver.Utils
{
    public class Camera
    {
        public Point3D Position = new Point3D();
    }
}