﻿public class BaseModel
{
    public string type;
}