﻿class GyroDataModel : BaseModel
{
    public double qW;
    public double qX;
    public double qY;
    public double qZ;
}