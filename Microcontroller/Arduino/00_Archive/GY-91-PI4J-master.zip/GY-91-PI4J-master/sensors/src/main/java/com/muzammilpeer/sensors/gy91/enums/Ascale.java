package com.muzammilpeer.sensors.gy91.enums;

public enum Ascale {
    AFS_2G,
    AFS_4G,
    AFS_8G,
    AFS_16G
}
