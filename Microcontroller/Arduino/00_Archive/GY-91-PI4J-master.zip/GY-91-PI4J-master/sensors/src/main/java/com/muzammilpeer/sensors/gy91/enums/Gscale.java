package com.muzammilpeer.sensors.gy91.enums;

public enum Gscale {
    GFS_250DPS,
    GFS_500DPS,
    GFS_1000DPS,
    GFS_2000DPS
}
