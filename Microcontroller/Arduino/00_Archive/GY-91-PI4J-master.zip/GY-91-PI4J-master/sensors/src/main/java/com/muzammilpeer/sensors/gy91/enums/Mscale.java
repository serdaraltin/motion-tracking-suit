package com.muzammilpeer.sensors.gy91.enums;

public enum Mscale {
    MFS_14BITS, // 0.6 mG per LSB
    MFS_16BITS      // 0.15 mG per LSB
}
