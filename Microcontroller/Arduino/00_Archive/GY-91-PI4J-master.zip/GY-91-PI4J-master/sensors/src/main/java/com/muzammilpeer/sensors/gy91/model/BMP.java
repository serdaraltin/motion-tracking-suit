package com.muzammilpeer.sensors.gy91.model;

public class BMP {
    public int chip_id;
    public int chip_version;
    public double temperature;
    public double pressure;
    public double altitude;
}
