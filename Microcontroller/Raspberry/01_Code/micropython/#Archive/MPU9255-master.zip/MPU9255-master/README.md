# MPU9255
Simple repository to get data from <a href="https://www.invensense.com/products/motion-tracking/9-axis/mpu-9255-2/">MPU-9255</a> sensor in python and at the end, trying to track the position using Kalman filter as a complete project. <br />
This Repository is created after getting inspiration from different available resources. Some of them are<br />
1 - <a href="https://github.com/kevinwlu/iot">Professor Kevin Lu's Github</a><br />
2 - <a href="http://blog.bitify.co.uk/2013/11/interfacing-raspberry-pi-and-mpu-6050.html">Andrew Birkett's Blog</a><br />
3 - <a href="https://github.com/balzer82/Kalman">Balzer82's Github</a><br />
