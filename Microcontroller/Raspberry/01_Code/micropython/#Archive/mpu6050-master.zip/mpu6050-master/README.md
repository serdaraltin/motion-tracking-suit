# MPU6050
Micropython driver for MPU-6050 inertial measurement unit.

Progress before I fried my imu with solder iron._.

See mpu6050/example.py for my prototyping script.
