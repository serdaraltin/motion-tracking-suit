import pyb
from pyb import Timer, Pin
import cmath
"""
入口参数：编码器读取频率

# 编码器电机参数参考
    1.光电编码器电机(MG513P30_12V)的参数：
        减速比：1:30
        分辨率（电机驱动线数）：500ppr（编码器精度，转一圈输出的脉冲数）

    2.霍尔编码器电机()的参数：
        减速比：1:30
        分辨率：13ppr

# 底盘机械参数参考
    标准轮式机器人硬件尺寸参数：
        轮子直径：6.5cm
        两轮间距：16cm

    履带式机器人硬件尺寸参数：
        轮子直径：4cm
        两轮间距：23cm
"""

class Encoder:
    '''
    机器人自身及编码器电机配置
    '''
    def __init__(self, encoder_freq):
        '''————————————————————————————可调参数——————————————————————————————————'''
        # -------机器人机械参数--------
        self.wheel_distance = 0.160         # 轮间距，单位:cm
        self.Wheel_diameter = 0.065         # 轮直径：单位:cm
        # -------机器人编码器电机参数--------
        reduction_ratio = 1/30              # 减速比，
        resolution_ratio = 500              # 分辨率，单位:ppr
        
        '''————————————————————————————系统参数——————————————————————————————————'''
        #配置编码器AB相读取模式,利用定时器中断进行读取
        p1_A = Pin("Y1"); p2_A = Pin("Y2");
        tim_A = Timer(8)
        tim_A.init(prescaler=0,period=10000)
        ch1_A = tim_A.channel(1,Timer.ENC_AB,pin=p1_A); ch2_A = tim_A.channel(2,Timer.ENC_AB, pin=p2_A);
        p1_B = Pin("X1"); p2_B = Pin("X2");
        tim_B = Timer(5)
        tim_B.init(prescaler=0,period=10000)
        ch1_B = tim_B.channel(1,Timer.ENC_AB,pin=p1_B); ch2_B = tim_B.channel(2,Timer.ENC_AB, pin=p2_B)
        
        # 初始化系统参数
        freq_multiplier = 4 # 倍频数
        self.pi = cmath.pi # pi的值
        self.encoder_freq = encoder_freq
        self.encoder_precision = freq_multiplier * resolution_ratio / reduction_ratio # 编码器精度 = 倍频数*编码器精度（电机驱动线数）*电机减速比
        self.tim_A = tim_A
        self.tim_B = tim_B
        self.encoder_A = 0
        self.encoder_B = 0
        # 定时器中断：固定时间读取编码器数值
        timer_read = Timer(10,freq=self.encoder_freq,callback=self.encoder_cb)

    def encoder_cb(self, encoder):
        '''
        函数功能：通过定时器中断读取编码器A、B计数值，并重置编码器
        '''    
        if self.tim_B.counter() > 5000:
            self.encoder_B = 10000 - self.tim_B.counter()
        else:
            self.encoder_B = -self.tim_B.counter()
        self.tim_B.counter(0)
        if self.tim_A.counter() > 5000:
            self.encoder_A = -(10000 - self.tim_A.counter()) 
        else:
            self.encoder_A = self.tim_A.counter()
        self.tim_A.counter(0)

    def target_enc_process(self, speed):
        '''
        函数功能：将目标速度值转化为目标编码器值
        入口参数：目标速度值
        返回值  ：目标编码器值
        # 目标编码器值=(目标速度*编码器精度)/(轮子周长*控制频率)
        '''
        enc = (speed*self.encoder_precision) / ( (self.pi*self.Wheel_diameter) * self.encoder_freq)
        return enc
    
    def enc_to_speed(self, enc):
        '''
        函数功能：将编码器值转化为速度值
        入口参数：编码器值
        返回值：速度值
        速度值=(采集到的脉冲数/编码器精度)*轮子周长*控制频率
        '''
        speed = (enc / self.encoder_precision) * (self.pi*self.Wheel_diameter) * self.encoder_freq
        return speed
    
    '''
    # 已知量，单位m
        v = 0 # 机器人的线速度
        w = 0 # 机器人的角速度
        v_l = 0 # 左轮速度
        v_r = 0 # 右轮速度
        D = 0.2 # 轮间距
        d = D/2
    # 速度、角速度、左右轮速的关系式
        v_l = v + wd
        v_r = v - wd
        v = (v_l + v_r)/2 
        w = (v_l - v_r)/D
    '''

    def speed_to_anglin(self, speed_A, speed_B):
        '''
        函数功能：将两轮速度值转化为角速度和线速度值
        入口参数：两轮速度值
        返回值：角速度，线速度
        '''
        linear_vel = (speed_A + speed_B)/2
        angular_vel = (speed_B - speed_A)/self.wheel_distance
        return angular_vel, linear_vel

    def anglin_to_speed(self, angular_vel, linear_vel):
        '''
        函数功能：将角速度和线速度值转化为两轮速度值
        入口参数：角速度，线速度
        返回值：两轮速度值
        '''
        speed_A = linear_vel - angular_vel * self.wheel_distance/2
        speed_B = linear_vel + angular_vel * self.wheel_distance/2
        return speed_A, speed_B
    