# pyb类库
import pyb
from pyb import LED, Switch, Timer, UART
from machine import I2C,Pin
import utime, time
# 外设库
import ps2
import encoder
import pid
import motor
import serial
from mpu9250 import MPU9250
# 核心控制代码库
from maincontrol import *

def mainTimer_cb(cb):
    '''
    函数功能：main函数的定时器中断函数，用于总体程序逻辑的定时执行
    修改：修改对应的程序时间，以及程序的功能标志位(flag)
    '''
    global count, reset_flag, dirver_flag, toggle_flag
    LED(3).toggle()
    count += 1
    if (count%1000) == 0: # 重置计数 1s
        reset_flag = True
    if (count%20) == 0:  # 20ms
        dirver_flag = True # pid刷新并控制电机(实际耗时：10ms)
    if (count%500) == 0: # LED闪烁 500ms
        toggle_flag = True

if __name__ == '__main__':

    '''————————————————————————————upybot机器人通用平台可调参数——————————————————————————————————'''
    '''
        机器人参数整定：
        1.先在encoder.py中调整机器人机械参数、编码器参数
        2.调整以下PID参数，一般只用PI即可。
    '''
    # -------光电编码器PID参数--------
    kp_A = 0.8 / 40 
    ki_A = 0.3 / 40
    kd_A = 0
    kp_B = 1.0 / 40
    ki_B = 0.3 / 40
    kd_B = 0
    # -------霍尔编码器PID参数--------
    # kp_A = 1.0
    # ki_A = 0.3
    # kd_A = 0
    # kp_B = 1.0
    # ki_B = 0.3
    # kd_B = 0

    '''————————————————————————————系统参数——————————————————————————————————'''
    # 初始化程序标志位
    count = 0 # 程序定时计数初值
    reset_flag = False
    toggle_flag = False
    dirver_flag = False
    # ps2手柄标志位
    joy_mode = False
    key_mode = False
    # ros和ps手柄控制模式
    ros_mode = True # 默认为ROS模式
    ps2_mode = False
    
    # 初始化系统参数
    pwm_range = 100 # PWM的范围（0-100）,默认值，不要改动
    encoder_freq = 100 # 编码器读取频率,和电机控制频率相同
    ps_list = [] # PS2手柄控制
    last_rec_data = (0,0) # 给串口上一帧赋初值
    gyro = [0, 0, 0]
    gyro_ratio = 1/(180/3.1415926)  # °/s 转成弧度/s
#-----------------------外设初始化--------------------------#
    # 按键初始化
    print("模式选择按键初始化----")
    LED(4).on()
    mode_sw = Switch()
    mode_sw.callback(lambda:pyb.LED(4).toggle()) # 按键选择工作模式，ros和ps2手柄
    # 定时器初始化：主程序逻辑控制，频率为1000Hz，每次计时1ms
    print("主控定时器初始化----")
    mainTimer = Timer(1, freq=1000, callback=mainTimer_cb) 
    # MPU9250初始化
    print("MPU9250初始化----")
    imu = MPU9250('X')
    accel_tuple = (imu.accel.xyz, imu.gyro.xyz, imu.mag.xyz)
    # PS2手柄初始化
    print("PS2手柄初始化----")
    ps = ps2.PS2KEY('X18','X19','X20','X21')
    static_key = ps.ps2_key()
    # 上下位机串口初始化
    print("串口通信初始化----")
    uart = UART(2, 115200, timeout=2) # 直接使用串口模块连接UART2
    ser = serial.Serial(uart)
    rec_data = None
    # 编码器初始化
    print("编码器初始化----")
    enc = encoder.Encoder(encoder_freq)
    # 初始化PID控制器
    print("PID初始化----")
    pid = pid.PID(pwm_range, kp_A, ki_A, kd_A, kp_B, ki_B, kd_B)
    # 初始化电机
    print("电机初始化----")
    motor = motor.Motor(pwm_range)
    # 初始化运动控制
    print("主控逻辑初始化----")
    psdriver = Ps2_Driver(enc, pid, motor)
    psdriver.ps2_driver_init()
    rosdriver = ROS_Driver(enc, pid, motor)

#-----------------------逻辑循环--------------------------#
    while True:        

        # 重置计数器 1s
        if reset_flag == True:
            count = 0
            reset_flag = False
        
        # 主控逻辑，刷新时间约为8-9ms
        if dirver_flag == True:

            # 初始化目标值
            target_enc_A = 0
            target_enc_B = 0

            # 获取当前编码器值
            enc_A = enc.encoder_A  
            enc_B = enc.encoder_B 
            speed_A = enc.enc_to_speed(enc_A)
            speed_B = enc.enc_to_speed(enc_B)
            angular_vel, linear_vel = enc.speed_to_anglin(speed_A, speed_B)
            
            # 模式选择
            status = LED(4).intensity() # 获取蓝色的模式指示灯状态
            if status == 0: # ps2_mode
                ps2_mode = True
                ros_mode = False
            elif status == 255: # ros modes
                ros_mode = True
                ps2_mode = False
            
            # --------------ROS控制模式----------------
            if ros_mode == True:
                # 获取ROS工作状态
                rec_data = ser.rev_data() # 串口读取数据
                if rec_data == None: # 如果为空数据就用上一帧数据
                    rec_data = last_rec_data
 
                # 分割数据
                speed_data = rec_data

                # 底盘运动控制
                target_speed_A, target_speed_B = rosdriver.speed_control(speed_data[0], speed_data[1])
                target_enc_A = enc.target_enc_process(target_speed_A)
                target_enc_B = enc.target_enc_process(target_speed_B)
                rosdriver.driver(target_enc_A, target_enc_B, enc_A, enc_B)
                
                # 串口发送数据
                zip_data = ser.format_data((angular_vel, linear_vel))
                ser.send_data(zip_data)
                
                last_rec_data = rec_data # 保留上一帧数据
            
            # --------------PS2手柄控制模式-----------------
            elif ps2_mode == True:
                # 获取PS2手柄工作状态数据
                key = ps.ps2_key()
                joy_data = ps2.data
                key_mode = True if (joy_data[1] == 160) else False # 按键标志位（默认）
                joy_mode = True if (joy_data[1] == 185) else False # 摇杆标志位

                # PID调参
                # if key == 11 or key == 12:
                #     pid.pid_params_edit(key)

                # 异常处理：防止手柄关闭后，接收器出现异常发生跳动或一直低速前进的的问题
                ps_list.append(joy_data[8])
                if len(ps_list) == 8: # 取5个值，只要值最多的是192就说明手柄已经关闭，应当保持静止
                    ps_list.pop(0)
                
                # 手柄正常工作时：
                if (key != 0 and key != static_key) or (max(ps_list, key=ps_list.count) != 192 and joy_mode == True): # 当有按键值的时候，或者是摇杆模式下，说明PS2手柄在工作状态
                    if key_mode == True: # 按键模式
                        target_speed_A, target_speed_B = psdriver.ps2_keycontrol(key)
                        target_enc_A = enc.target_enc_process(target_speed_A)
                        target_enc_B = enc.target_enc_process(target_speed_B)
                        psdriver.driver(target_enc_A, target_enc_B, enc_A, enc_B) # PS2手柄控制
                        key_mode = False

                    elif joy_mode == True: # 摇杆模式

                        if max(ps_list, key=ps_list.count) == 192:
                            target_speed_A, target_speed_B = 0, 0
                        # 正常情况
                        else:
                            target_speed_A, target_speed_B = psdriver.ps2_joycontrol(joy_data)
                        target_enc_A = enc.target_enc_process(target_speed_A)
                        target_enc_B = enc.target_enc_process(target_speed_B)
                        psdriver.driver(target_enc_A, target_enc_B, enc_A, enc_B) # PS2手柄控制
                        joy_mode = False
                    else:
                        target_speed_A, target_speed_B = 0, 0
                        target_enc_A = enc.target_enc_process(target_speed_A)
                        target_enc_B = enc.target_enc_process(target_speed_B)
                        rosdriver.driver(target_enc_A, target_enc_B, enc_A, enc_B)

            # -------匿名工作站上位机调参-------
            # ser.serial_to_station(target_enc_A, enc_A, target_enc_B, enc_B )
            # -------命令行打印数据------- 
            # print(str(target_enc_A), str(enc_A), str(target_enc_B), str(enc_B))
            
            # imu数据读取
            try:
                gyro[0] = imu.gyro.xyz[0]*gyro_ratio;
                gyro[1] = imu.gyro.xyz[1]*gyro_ratio;
                gyro[2] = imu.gyro.xyz[2]*gyro_ratio;
                
                accel_tuple = (imu.accel.xyz, (gyro[0], gyro[1], gyro[2]), imu.mag.xyz)
                # print(accel_tuple)
            except OSError:
                accel_tuple = accel_last_tuple
            accel_last_tuple = accel_tuple
            
            dirver_flag = False
                
        # LED闪烁 500ms
        if toggle_flag == True:
            LED(2).toggle()
            toggle_flag = False