import pyb
'''
PID使用说明：
    输入参数：当前的编码器值，目标速度对应的编码器值
    输出参数：此时应当的给电机的pwm值
'''
class PID:
    def __init__(self, pwm_range, kp_A, ki_A, kd_A, kp_B, ki_B, kd_B):
        pwm_A = 0
        pwm_B = 0
        err = 0
        err_A = 0
        err_B = 0
        last_err_A = 0
        last_err_B = 0
        self.pwm_range = pwm_range
        self.kp_A = kp_A
        self.ki_A = ki_A
        self.kd_A = kd_A
        self.kp_B = kp_B
        self.ki_B = ki_B
        self.kd_B = kd_B
        self.pwm_A = 0
        self.pwm_B = 0
        self.err = err
        self.err_A = err_A
        self.err_B = err_B
        self.last_err_A = last_err_A
        self.last_err_B = last_err_B
    
    # 增量PID原理代码
    def incremental_pid(self, now, target):
        '''
        函数功能：增量PI控制器
        入口参数：当前的编码器值，目标速度对应的编码器值
        返回值  ：电机PWM
        根据增量式离散PID公式：
        pwm += Kp[e(k) - e(k-1)] + Ki*e(k) + Kd[e(k) - 2e(k-1) + e(k-2)]
        e(k)代表本次偏差；
        e(k-1)代表上一次的偏差；    以此类推
        pwm代表增量输出。
        '''
        err = target - now
        pwm = pwm + self.kp*(err - last_err) + self.ki*err + self.kd*(err - last_err)
        if (pwm >= self.pwm_range): # 限幅，防止pwm值超出100
            pwm = self.pwm_range
        if (pwm <= -self.pwm_range):
            pwm = -self.pwm_range
        last_err = err
        return pwm

    def pid_A(self, now, target):
        self.err_A = target - now
        self.pwm_A = self.pwm_A + self.kp_A*(self.err_A - self.last_err_A) + self.ki_A*self.err_A + self.kd_A*(self.err_A - self.last_err_A)
        if (self.pwm_A >= self.pwm_range):
            self.pwm_A = self.pwm_range
        if (self.pwm_A <= -self.pwm_range):
            self.pwm_A = -self.pwm_range
        self.last_err_A = self.err_A
        return self.pwm_A

    def pid_B(self, now, target):
        self.err_B = target - now
        self.pwm_B = self.pwm_B + self.kp_B*(self.err_B - self.last_err_B) + self.ki_B*self.err_B + self.kd_B*(self.err_B - self.last_err_B)
        if (self.pwm_B >= self.pwm_range):
            self.pwm_B = self.pwm_range
        if (self.pwm_B <= -self.pwm_range):
            self.pwm_B = -self.pwm_range
        self.last_err_B = self.err_B
        return self.pwm_B

    def pid_params_edit(self, key):
        if key == 13:
            self.kp_A += 0.2
            # self.err_A = 0
        elif key == 15:
            self.kp_A -= 0.2
            # self.err_A = 0
        print("pid params   ", "P:", str(self.kp_A), "I", str(self.ki_A))
        # pyb.hard_reset()
        
        
        pyb.delay(100)
        return self.kp_A, self.ki_A