# Sensortest
Python Class Library for Raspberry Pi

Supported device list: MPU-6050, MPU-9250, HMC5883L, BMP280, BME280, HC-SR04, PCA9685

Requirements:
Hardware: Raspberry Pi
Software: Raspbian, python

More information:
http://avislab.com/blog

http://www.youtube.com/channel/UCRu6XayQfW-augguSYhStyg
