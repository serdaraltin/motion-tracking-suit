# Move Rig.blend
open this file and use it with the python script to apply poses to the rig in the blend file.  The sensors on the rig can be tweaked prior to applying a pose to adjust for off kilter sensors during the acquisition.


# You must install PySerial into blender python for the scripts to work!
for instructions on how to install it watch this tutorial:
https://www.youtube.com/watch?v=CypV9pPTCXo


# Waist and Arfuino and Accel Case blend files
These files contain all of the 3d printable models to create the suit.
