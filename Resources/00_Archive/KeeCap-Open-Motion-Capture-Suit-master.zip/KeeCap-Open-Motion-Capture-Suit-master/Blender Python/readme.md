This code works in blender 2.83.

If you want to test the PC only side without a suit you can use the latest python script from this dir in blender 2.83 and open the Move rig.blend from the blender dir.

# You must install PySerial into blender python for the scripts to work!
for instructions on how to install it watch this tutorial:
https://www.youtube.com/watch?v=CypV9pPTCXo


Move Object Tester is old and does not work at the moment.
