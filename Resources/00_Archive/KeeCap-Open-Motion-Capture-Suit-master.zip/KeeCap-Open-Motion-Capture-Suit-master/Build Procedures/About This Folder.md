This folder contains the build procedures for the various parts of the suit.
