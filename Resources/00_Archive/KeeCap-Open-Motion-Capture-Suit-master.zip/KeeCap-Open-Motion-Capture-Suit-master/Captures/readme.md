This directory contains some captures I did during testing, your mileage may vary as many were done during developemnt.

The sit gesture contains a recent capture with matching video of the capture for reference.
