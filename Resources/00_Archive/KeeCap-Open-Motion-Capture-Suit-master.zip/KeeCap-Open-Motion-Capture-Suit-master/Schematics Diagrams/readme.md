This folder contains all of the schematics and diagrams for building the suit
