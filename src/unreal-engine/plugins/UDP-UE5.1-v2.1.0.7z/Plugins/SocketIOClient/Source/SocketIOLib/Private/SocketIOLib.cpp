// Copyright 2018-current Getnamo. All Rights Reserved


#include "SocketIOLib.h"


//struct 

class FSocketIOLibModule : public ISocketIOLibModule
{
};


IMPLEMENT_MODULE(FSocketIOLibModule, SocketIOLib)