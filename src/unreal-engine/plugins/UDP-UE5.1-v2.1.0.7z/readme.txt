Quick Install & Setup

1. Create new or choose project.
2. Browse to your project folder (typically found at Documents/Unreal Project/{Your Project Root})
3. Copy Plugins folder into your Project root.
4. Plugin is now ready to use.

Refer to https://github.com/getnamo/UDP-Unreal for detailed instructions